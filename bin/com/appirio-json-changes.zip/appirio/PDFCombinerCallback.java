package com.appirio;

import java.io.Serializable;

/**
 * @author jesus
 *
 * This class receives a callback url and parameters to send back to the server
 * when the pdf generation is complete.
 */
public class PDFCombinerCallback implements Serializable {
	private static final long serialVersionUID = 343452324L;
	private String callbackUrl;
	//private CallbackContents callbackContents;
	private String callbackContents;
	public PDFCombinerCallback() {
		super();
	}
	public String getCallbackUrl() {
		System.out.println(" getCallbackUrl " +callbackUrl);
		return callbackUrl;
	}
	public void setCallbackUrl(String callbackUrl) {
		System.out.println(" setCallbackUrl " +callbackUrl);
		this.callbackUrl = callbackUrl;
	}
	public String getCallbackContents() {
		System.out.println(" getCallbackContents " +callbackContents);
		return callbackContents;
	}
	public void setCallbackContents(String callbackContents) {
		System.out.println(" setCallbackContents " +callbackContents);
		this.callbackContents = callbackContents;
	}
}
