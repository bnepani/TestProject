package com.appirio;

import java.io.Serializable;

/**
 * @author jesus
 *
 * This class receives a callback url and parameters to send back to the server
 * when the pdf generation is complete.
 */
public class CallbackContents implements Serializable {
	private static final long serialVersionUID = 343452324L;
	
	private String Status__c;
	private String Message__c;
	private String pdf_Output__c;
	
	
	public String getStatus__c() {
		return Status__c;
	}
	public void setStatus__c(String status__c) {
		Status__c = status__c;
	}
	public String getMessage__c() {
		return Message__c;
	}
	public void setMessage__c(String message__c) {
		Message__c = message__c;
	}
	
	  
  }
	 
	 
 

	
	
